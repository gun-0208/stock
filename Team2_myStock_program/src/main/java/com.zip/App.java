package com;

import java.util.Scanner;

import org.jsoup.nodes.Document;

import com.stockController.StockController;

public class App {
	private static StockController stockController = new StockController();
	
	public static void main(String[] args) {
		// 콘솔창을 통해 입력 받을 수 있도록 조치
		Scanner sc = new Scanner(System.in);
		// 시스템 반복 입력 요청
		boolean run = true;
		System.out.println("주식 프로그램 활성화 완료. 어서오세요.");
		System.out.println("콘솔창을 활용하여 원하는 메뉴를 선택해주세요.");
		System.out.println("기본 값으로는 삼성전자가 등록되어있습니다.");
		// defalt 값 나열
		String stockCode = "005930";//변수  기간을 언제까지?
		String URL = String.format("https://finance.naver.com/item/sise_day.naver?code=%s&page=1", stockCode);
		Document doc = null;
		while (run) {
			System.out.println("");
			System.out.println("-------------------------------------");
			System.out.println("1.회원가입 | 2.관심 주식 조회  | 3.내 정보 조회 | 4.내 주식 매수/매도 | 5.저장 후 종료");
			System.out.println("-------------------------------------");
			System.out.print("선택>");
			int menuNum = sc.nextInt();
			switch (menuNum) {
			case 1:
				// 컨트롤러, 회원가입
				
			case 2:
				// 컨트롤러, 관심 주식 조회
				stockController.insertStock(stockCode);
			case 3:
				// 컨트롤러, 내 정보 조회
				
				
			case 4:
				// 컨트롤러 매수, 매도
				
			case 5:
				// 저장 후 종료
				
				run = false;
				break;
			} System.out.println("프로그램을 종료하겠습니다.");
			
		}
	}
}
		

		
