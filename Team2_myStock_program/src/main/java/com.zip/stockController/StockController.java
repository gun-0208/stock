package com.stockController;

import java.util.List;

import com.model.Stock;
import com.stockDAO.StockParser;
import com.stockService.StockService;

public class StockController {
	private static StockService stockService;
	private static StockParser stockParser;

	
	
	public void insertStock(String stockCode) {
		List<Stock> stockList = stockParser.stockParser(stockCode);
		
		stockService.insertStock(stockList,stockCode);
		
		
	}

}
