package com.stockService;

import java.util.List;

import com.model.Stock;
import com.stockDAO.StockDAO;

public class StockService {
	private static StockDAO stockDAO;
	
	
	public void insertStock(List<Stock> stockList,String stockCode) {
		stockDAO.insertStock(stockList,stockCode);
	}

}
